# analyse_hackathon

This library was created as my submission to the EDSA 2019 Analyse Sprint Hackathon.

## building this package locally
`python setup.py sdist`

## installing this package from GitHub
`pip install git+https://github.com/Francorider/analyse_hackathon.git`

## updating this package from GitHub
`pip install --upgrade git+https://github.com/Francorider/analyse_hackathon.git`
